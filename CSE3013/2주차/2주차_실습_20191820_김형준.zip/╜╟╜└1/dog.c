#include "animal.h"
void dog_func()
{
	printf("dog\n");
}

