#include "animal.h"

int main(void)
{
	printf("main\n");
	dog_func();
	blackcow_func();
	turtle_func();
}
