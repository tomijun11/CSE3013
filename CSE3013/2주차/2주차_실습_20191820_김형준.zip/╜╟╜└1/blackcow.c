#include "animal.h"
void blackcow_func()
{
	printf("blackcow\n");
}
