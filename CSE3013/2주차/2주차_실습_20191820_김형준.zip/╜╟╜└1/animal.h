#include <stdio.h>

void dog_func();
void blackcow_func();
void turtle_func();

