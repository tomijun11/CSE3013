#include "animal.h"
void turtle_func()
{
	printf("turtle\n");
}
