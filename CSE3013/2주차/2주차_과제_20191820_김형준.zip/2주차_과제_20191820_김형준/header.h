// 매크로정의 및 필요한 라이브러리 Include
#include <stdio.h>
#include <stdlib.h>
#define RET_SIZE 10

// 함수 선언
void inputpage(int** inputArr, int* num);
void countpage(int* arr, int num);
void printarr(int* arr, int size);
void cleararr(int* arr, int size);
