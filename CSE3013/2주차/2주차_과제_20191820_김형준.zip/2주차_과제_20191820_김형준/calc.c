#include "header.h" // 헤더파일 include
void countpage(int* arr, int num) // 페이지를 이루는 숫자들을 세는 함수
{
	/* num : 현재 페이지수, arr : 결과값을 저장하는 배열(ret)
	 num의 맨 끝자리수를 ret에 반영하고 10으로 계속 나눔,
	 num이 한자리수가 되면 ret에 반영후 실행종료
	*/
	while(1) { // 무한루프
		if (num<10) { // num이 10 미만이면
			arr[num]++; // num (한자리수)을 ret에 카운트함
			break; // 함수를 종료함
		}
		else { // num이 10 이상이면
			arr[num%10]++; // num의 맨 끝자리수(1의자리수)를 ret에 카운트함
			num/=10; // num을 10으로 나눔
		}
	}
}

void printarr(int* arr, int size) // 배열의 내용을 출력하는 함수
{
	/*
	arr : 출력할 배열, size : 배열의 크기
	*/
	int i; // 변수선언
	for(i=0;i<size;i++) // 배열의 크기만큼 반복
		if(i==size-1) // 배열의 마지막 원소이면
			printf("%d\n",arr[i]); // 해당 원소 출력후 개행
		else // 배열의 마지막 원소가 아니면
			printf("%d ",arr[i]); // 해당 원소 출력
}

void cleararr(int* arr, int size) // 배열의 값을 0으로 초기화하는 함수
{
	/*
	arr : 초기화 할 배열, size : 배열의 크기
	*/
	int i; // 변수선언
	for (i=0;i<size;i++) // 배열의 크기만큼 반복
		arr[i]=0; // 배열의 값 0으로 초기화
}
