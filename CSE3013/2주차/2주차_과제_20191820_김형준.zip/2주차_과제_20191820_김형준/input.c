#include "header.h" // 헤더파일 include
void inputpage(int** inputArr, int* num) // Input을 처리하는 함수
{
	/*
	num : 테스트 케이스의 갯수를 저장할 변수, inputArr : 입력된 페이지 수들을 저장할 배열
	*/
	int i; // 변수 선언
	scanf("%d",num); // 테스트 케이스의 개수를 입력받음 (num에 저장함)
	(*inputArr) = (int*)malloc((*num)*sizeof(int)); // 입력된 테스트 케이스의 개수만큼의 공간을 할당받음
	for(i=0;i<(*num);i++) // 테스트 케이스 개수만큼 반복
		scanf("%d",&((*inputArr)[i])); // inputArr에 각각의 페이지수를 저장함
}
