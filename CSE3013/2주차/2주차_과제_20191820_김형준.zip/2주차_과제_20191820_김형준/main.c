#include "header.h" // 헤더파일 Include

int main(void) // main 함수 정의
{
	int num, i, j; // 사용할 변수 선언
	int ret[RET_SIZE] = {0}; // 결과값을 담을 배열 선언 (0~9까지 각각 페이지를 이루는 숫자의 갯수를 저장함)
	int* inputArr; // Input 저장용 배열 포인터 선언
	
	inputpage(&inputArr,&num); // Input 처리 (num에 테스트 케이스 개수, inputArr에 각각의 페이지 수가 저장됨)
	
	for (i=0;i<num;i++) // 테스트 케이스 개수만큼 반복함
	{
		for(j=1;j<=inputArr[i];j++) // 1페이지부터 입력된 페이지까지 반복
			countpage(ret,j); // 현재 페이지를 이루는 숫자를 세서 ret에 갯수를 저장함
		printarr(ret,RET_SIZE); // ret에 저장된 값 출력
		cleararr(ret,RET_SIZE); // ret의 값 0으로 초기화
	}

	free(inputArr); // Input 저장용배열 메모리할당해제
	return 0; // 프로그램 종료
}

