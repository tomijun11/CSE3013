#include "ofApp.h"
#include <iostream>
using namespace std;
Room** Maze = NULL;
int Row, Col;
Node* Mtop = NULL;
QNode* Mfront = NULL, *Mrear = NULL, *Mptr, *Mprev = NULL;
#define baseX 15.0 
#define baseY 15.0 
#define Length 30.0

vector<Line> SPath, Path;
//--------------------------------------------------------------
void ofApp::setup() {

	ofSetWindowTitle("Maze Example"); // Set the app name on the title bar
	ofSetFrameRate(15);
	ofBackground(255, 255, 255);
	// Get the window size for image loading
	windowWidth = ofGetWidth();
	windowHeight = ofGetHeight();
	isdfs = false;
	isOpen = 0;
	// Centre on the screen
	ofSetWindowPosition((ofGetScreenWidth() - windowWidth) / 2, (ofGetScreenHeight() - windowHeight) / 2);

	// Load a font rather than the default
	myFont.loadFont("verdana.ttf", 12, true, true);

	// Load an image for the example
	//myImage.loadImage("lighthouse.jpg");

	// Window handle used for topmost function
	hWnd = WindowFromDC(wglGetCurrentDC());

	// Disable escape key exit so we can exit fullscreen with Escape (see keyPressed)
	ofSetEscapeQuitsApp(false);

	//
	// Create a menu using ofxWinMenu
	//

	// A new menu object with a pointer to this class
	menu = new ofxWinMenu(this, hWnd);

	// Register an ofApp function that is called when a menu item is selected.
	// The function can be called anything but must exist. 
	// See the example "appMenuFunction".
	menu->CreateMenuFunction(&ofApp::appMenuFunction);

	// Create a window menu
	HMENU hMenu = menu->CreateWindowMenu();

	//
	// Create a "File" popup menu
	//
	HMENU hPopup = menu->AddPopupMenu(hMenu, "File");

	//
	// Add popup items to the File menu
	//

	// Open an maze file
	menu->AddPopupItem(hPopup, "Open", false, false); // Not checked and not auto-checked

	// Final File popup menu item is "Exit" - add a separator before it
	menu->AddPopupSeparator(hPopup);
	menu->AddPopupItem(hPopup, "Exit", false, false);

	//
	// View popup menu
	//
	hPopup = menu->AddPopupMenu(hMenu, "View");

	bShowInfo = true;  // screen info display on
	menu->AddPopupItem(hPopup, "Show DFS", false, false); // Checked
	bTopmost = false; // app is topmost
	menu->AddPopupItem(hPopup, "Show BFS"); // Not checked (default)
	bFullscreen = false; // not fullscreen yet
	menu->AddPopupItem(hPopup, "Full screen", false, false); // Not checked and not auto-check

	//
	// Help popup menu
	//
	hPopup = menu->AddPopupMenu(hMenu, "Help");
	menu->AddPopupItem(hPopup, "About", false, false); // No auto check

	// Set the menu to the window
	menu->SetWindowMenu();

} // end Setup


//
// Menu function
//
// This function is called by ofxWinMenu when an item is selected.
// The the title and state can be checked for required action.
// 
void ofApp::appMenuFunction(string title, bool bChecked) {

	ofFileDialogResult result;
	string filePath;
	size_t pos;

	//
	// File menu
	//
	if (title == "Open") {
		readFile();
	}
	if (title == "Exit") {
		ofExit(); // Quit the application
	}

	//
	// Window menu
	//
	if (title == "Show DFS") {
		//doTopmost(bChecked);
		//bShowInfo = bChecked;  // Flag is used elsewhere in Draw()
		if (isOpen)
		{
			DFS();
			bShowInfo = bChecked;
		}
		else
			cout << "you must open file first" << endl;

	}

	if (title == "Show BFS") {
		//doTopmost(bChecked); // Use the checked value directly
		if (isOpen)
		{
			BFS();
			bShowInfo = bChecked;
		}
		else
			cout << "you must open file first" << endl;
	}

	if (title == "Full screen") {
		bFullscreen = !bFullscreen; // Not auto-checked and also used in the keyPressed function
		doFullScreen(bFullscreen); // But als take action immediately
	}

	//
	// Help menu
	//
	if (title == "About") {
		ofSystemAlertDialog("ofxWinMenu\nbasic example\n\nhttp://spout.zeal.co");
	}

} // end appMenuFunction


//--------------------------------------------------------------
void ofApp::update() {

}


//--------------------------------------------------------------
void ofApp::draw() {

	char str[256];
	//ofBackground(0, 0, 0, 0);
	ofSetColor(100);
	ofSetLineWidth(5);
	int i, j;

	// TO DO : DRAW MAZE; 
	// ����� �ڷᱸ���� �̿��� �̷θ� �׸���.
	// add code here
	
	// Draw Base
	ofDrawLine(baseX, baseY, baseX + Length * (Col), baseY);
	ofDrawLine(baseX, baseY, baseX, baseY + Length * (Row));
	
	// Draw Wall
	for (i = 0; i < Row; i++)
	{
		for (j = 0; j < Col; j++)
		{
			if (Maze[i][j].r == 1)
				ofDrawLine(baseX + (j+1) * Length, baseY + i * Length, baseX + (j+1) * Length, baseY + (i+1) * Length);
			if (Maze[i][j].d == 1)
				ofDrawLine(baseX + j * Length, baseY + (i+1) * Length, baseX + (j+1) * Length, baseY + (i+1) * Length);
		}

	}
	

	//����Ա���
	
	if (isdfs)
	{
		ofSetColor(200);
		ofSetLineWidth(5);
		if (isOpen)
			dfsdraw();
		else
			cout << "You must open file first" << endl;
	}
	if (isbfs)
	{
		ofSetColor(200);
		ofSetLineWidth(5);
		if (isOpen)
			dfsdraw();
		else
			cout << "You must open file first" << endl;
	}
	if (bShowInfo) {
		// Show keyboard duplicates of menu functions
		ofSetColor(200);
		sprintf(str, " comsil project");
		myFont.drawString(str, 15, ofGetHeight() - 20);
	}

} // end Draw


void ofApp::doFullScreen(bool bFull)
{
	// Enter full screen
	if (bFull) {
		// Remove the menu but don't destroy it
		menu->RemoveWindowMenu();
		// hide the cursor
		ofHideCursor();
		// Set full screen
		ofSetFullscreen(true);
	}
	else {
		// return from full screen
		ofSetFullscreen(false);
		// Restore the menu
		menu->SetWindowMenu();
		// Restore the window size allowing for the menu
		ofSetWindowShape(windowWidth, windowHeight + GetSystemMetrics(SM_CYMENU));
		// Centre on the screen
		ofSetWindowPosition((ofGetScreenWidth() - ofGetWidth()) / 2, (ofGetScreenHeight() - ofGetHeight()) / 2);
		// Show the cursor again
		ofShowCursor();
		// Restore topmost state
		if (bTopmost) doTopmost(true);
	}

} // end doFullScreen


void ofApp::doTopmost(bool bTop)
{
	if (bTop) {
		// get the current top window for return
		hWndForeground = GetForegroundWindow();
		// Set this window topmost
		SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ShowWindow(hWnd, SW_SHOW);
	}
	else {
		SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		ShowWindow(hWnd, SW_SHOW);
		// Reset the window that was topmost before
		if (GetWindowLong(hWndForeground, GWL_EXSTYLE) & WS_EX_TOPMOST)
			SetWindowPos(hWndForeground, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
		else
			SetWindowPos(hWndForeground, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
	}
} // end doTopmost


//--------------------------------------------------------------
void ofApp::keyPressed(int key) {

	// Escape key exit has been disabled but it can be checked here
	if (key == VK_ESCAPE) {
		// Disable fullscreen set, otherwise quit the application as usual
		if (bFullscreen) {
			bFullscreen = false;
			doFullScreen(false);
		}
		else {
			ofExit();
		}
	}

	// Remove or show screen info
	if (key == ' ') {
		bShowInfo = !bShowInfo;
		// Update the menu check mark because the item state has been changed here
		menu->SetPopupItem("Show DFS", bShowInfo);
	}

	if (key == 'f') {
		bFullscreen = !bFullscreen;
		doFullScreen(bFullscreen);
		// Do not check this menu item
		// If there is no menu when you call the SetPopupItem function it will crash
	}

} // end keyPressed

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {

}
bool ofApp::readFile()
{
	ofFileDialogResult openFileResult = ofSystemLoadDialog("Select .maz file");
	string filePath;
	size_t pos;
	// Check whether the user opened a file
	if (openFileResult.bSuccess) {
		ofLogVerbose("User selected a file");

		//We have a file, check it and process it
		string fileName = openFileResult.getName();
		//string fileName = "maze0.maz";
		printf("file name is %s\n", fileName.c_str());
		filePath = openFileResult.getPath();
		printf("Open\n");
		pos = filePath.find_last_of(".");
		if (pos != string::npos && pos != 0 && filePath.substr(pos + 1) == "maz") {

			ofFile file(fileName);

			if (!file.exists()) {
				cout << "Target file does not exists." << endl;
				return false;
			}
			else {
				cout << "We found the target file." << endl;
				isOpen = 1;
			}

			ofBuffer buffer(file);

			// Input_flag is a variable for indication the type of input.
			// If input_flag is zero, then work of line input is progress.
			// If input_flag is one, then work of dot input is progress.
			int input_flag = 0;

			// Idx is a variable for index of array.
			int idx = 0;

			// Read file line by line
			int cnt = 0;


			// TO DO
			// .maz ������ input���� �޾Ƽ� ������ �ڷᱸ���� �ִ´�
			freeMemory();

			isbfs = 0;
			isdfs = 0;
			string templine = buffer.getFirstLine();
			Col = (templine.size() - 1) / 2;
			Row = 0;
			int loop;
			while(1)
			{
				templine = buffer.getNextLine();
				if (templine.size() < Col)
					break;
				Row++;
			}
			Row /= 2;

			int i, j;
			Maze = (Room**)malloc(sizeof(Room*) * Row);
			for (i = 0; i < Row; i++)
				Maze[i] = (Room*)malloc(sizeof(Room) * Col);

			for (i = 0; i < Row; i++)
				for (j = 0; j < Col; j++)
				{
					Maze[i][j].visited = 0;
					Maze[i][j].r = 1;
					Maze[i][j].d = 1;
				}

			templine = buffer.getFirstLine();
			for (i = 0; i < Row; i++)
			{
				string rline = buffer.getNextLine();
				string dline = buffer.getNextLine();
				for (j = 0; j < Col; j++)
				{
					// fill rwall
					if (j < Col - 1)
					{
						if (rline[2 * j + 2] == ' ')
							Maze[i][j].r = 0;
					}

					// fill dwall
					if (i < Row - 1)
					{
						if (dline[2 * j + 1] == ' ')
							Maze[i][j].d = 0;
					}
				}
			}
			
			//����Ա���

		}
		else {
			printf("  Needs a '.maz' extension\n");
			return false;
		}
	}
}
void ofApp::freeMemory() {

	//TO DO
	// malloc�� memory�� free���ִ� �Լ�

	int i;
	if (Maze != NULL)
	{
		for (i = 0; i < Row; i++)
			free(Maze[i]);
		free(Maze);
		Maze = NULL;
	}
	
	ClearStack();
	ClearQueue();

	Path.clear();
	SPath.clear();

	// freeMemory ȣ����ġ Ȯ��
	// DFS BFS ��ġ ȭ�� ���ſ� �ݿ�
	// Stack Queue Vector ���� �߰�
}

void ofApp::dfsdraw()
{
	//TO DO 
	//DFS�� ������ ����� �׸���. (3���� ����)
	int i;
	ofSetColor(255, 0, 0); // Search Path 
	for (i = 0; i < SPath.size(); i++)
	{
		Line ltemp = SPath.at(i);
		ofDrawLine(ltemp.x1, ltemp.y1, ltemp.x2, ltemp.y2);
	}

	ofSetColor(0, 255, 0); // path
	for (i = 0; i < Path.size(); i++)
	{
		Line ltemp = Path.at(i);
		ofDrawLine(ltemp.x1, ltemp.y1, ltemp.x2, ltemp.y2);
	}
	//�������ġ
}


bool ofApp::DFS()//DFSŽ���� �ϴ� �Լ�
{
	//TO DO
	//DFSŽ���� �ϴ� �Լ� (3����)
	isdfs = true;
	int i, j;

	// �ʱ�ȭ
	for (i = 0; i < Row; i++)
		for (j = 0; j < Col; j++)
			Maze[i][j].visited = 0;

	ClearStack();
	SPath.clear();
	Path.clear();

	Push(0, 0); // ������ ��ġ
	Maze[0][0].visited = 1;
	while (Mtop != NULL)
	{
		i = Mtop->row;
		j = Mtop->col;

		if (i == Row - 1 && j == Col - 1) // ������ ��ġ
			break;

		if (Maze[i][j].r == 0 && Maze[i][j + 1].visited == 0) // r Ž��
		{
			Maze[i][j + 1].visited = 1;
			Push(i, j + 1);

			Line ltemp = { baseX + Length * (j + 0.5), baseY + Length * (i + 0.5), baseX + Length * (j + 1.5), baseY + Length * (i + 0.5) };
			SPath.push_back(ltemp);
		}
		else if (Maze[i][j].d == 0 && Maze[i + 1][j].visited == 0) // d Ž��
		{
			Maze[i + 1][j].visited = 1;
			Push(i + 1, j);

			Line ltemp = { baseX + Length * (j + 0.5), baseY + Length * (i + 0.5), baseX + Length * (j + 0.5), baseY + Length * (i + 1.5) };
			SPath.push_back(ltemp);
		}
		else if (j > 0 && Maze[i][j - 1].r == 0 && Maze[i][j - 1].visited == 0) // l Ž��
		{
			Maze[i][j - 1].visited = 1;
			Push(i, j - 1);

			Line ltemp = { baseX + Length * (j + 0.5), baseY + Length * (i + 0.5), baseX + Length * (j - 0.5), baseY + Length * (i + 0.5) };
			SPath.push_back(ltemp);
		}
		else if (i > 0 && Maze[i - 1][j].d == 0 && Maze[i - 1][j].visited == 0) // u Ž��
		{
			Maze[i - 1][j].visited = 1;
			Push(i - 1, j);

			Line ltemp = { baseX + Length * (j + 0.5), baseY + Length * (i + 0.5), baseX + Length * (j + 0.5), baseY + Length * (i - 0.5) };
			SPath.push_back(ltemp);
		}
		else
			Pop(&i, &j);
	}

	int ni, nj;
	Pop(&i, &j);
	for (; Mtop != NULL;)
	{
		ni = Mtop->row;
		nj = Mtop->col;
		if (ni == i) // r l
		{
			if (nj > j) // l
			{
				Line ltemp = { baseX + Length * (nj + 0.5), baseY + Length * (ni + 0.5), baseX + Length * (nj - 0.5), baseY + Length * (ni + 0.5) };
				Path.push_back(ltemp);
			}
			else // r
			{
				Line ltemp = { baseX + Length * (nj + 0.5), baseY + Length * (ni + 0.5), baseX + Length * (nj + 1.5), baseY + Length * (ni + 0.5) };
				Path.push_back(ltemp);
			}
		}
		else if (nj == j) // d u
		{
			if (ni > i) // u
			{
				Line ltemp = { baseX + Length * (nj + 0.5), baseY + Length * (ni + 0.5), baseX + Length * (nj + 0.5), baseY + Length * (ni - 0.5) };
				Path.push_back(ltemp);
			}
			else // d
			{
				Line ltemp = { baseX + Length * (nj + 0.5), baseY + Length * (ni + 0.5), baseX + Length * (nj + 0.5), baseY + Length * (ni + 1.5) };
				Path.push_back(ltemp);
			}
		}

		Pop(&i, &j);
	}

	//�������ġ
	return 0;
}


bool ofApp::BFS()//DFSŽ���� �ϴ� �Լ�
{
	//TO DO
	//BFSŽ���� �ϴ� �Լ� (3����)
	isbfs = true;
	int i, j;

	// �ʱ�ȭ
	for (i = 0; i < Row; i++)
		for (j = 0; j < Col; j++)
			Maze[i][j].visited = 0;

	ClearQueue();
	SPath.clear();
	Path.clear();


	Enqueue(0, 0,-1,-1); // ������ ��ġ
	Maze[0][0].visited = 1;
	Mptr = Mfront; // ���Ḯ��Ʈ ������ backup
	while (Mfront != NULL)
	{
		Dequeue(&i, &j);

		if (i == Row - 1 && j == Col - 1) // ������ ��ġ
			break;

		if (Maze[i][j].r == 0 && Maze[i][j + 1].visited == 0) // r Ž��
		{
			Maze[i][j + 1].visited = 1;
			Enqueue(i, j + 1, i, j);

			Line ltemp = { baseX + Length * (j + 0.5), baseY + Length * (i + 0.5), baseX + Length * (j + 1.5), baseY + Length * (i + 0.5) };
			SPath.push_back(ltemp);
		}
		if (Maze[i][j].d == 0 && Maze[i + 1][j].visited == 0) // d Ž��
		{
			Maze[i + 1][j].visited = 1;
			Enqueue(i + 1, j, i, j);

			Line ltemp = { baseX + Length * (j + 0.5), baseY + Length * (i + 0.5), baseX + Length * (j + 0.5), baseY + Length * (i + 1.5) };
			SPath.push_back(ltemp);
		}
		if (j > 0 && Maze[i][j - 1].r == 0 && Maze[i][j - 1].visited == 0) // l Ž��
		{
			Maze[i][j - 1].visited = 1;
			Enqueue(i, j - 1, i, j);

			Line ltemp = { baseX + Length * (j + 0.5), baseY + Length * (i + 0.5), baseX + Length * (j - 0.5), baseY + Length * (i + 0.5) };
			SPath.push_back(ltemp);
		}
		if (i > 0 && Maze[i - 1][j].d == 0 && Maze[i - 1][j].visited == 0) // u Ž��
		{
			Maze[i - 1][j].visited = 1;
			Enqueue(i - 1, j, i, j);

			Line ltemp = { baseX + Length * (j + 0.5), baseY + Length * (i + 0.5), baseX + Length * (j + 0.5), baseY + Length * (i - 0.5) };
			SPath.push_back(ltemp);
		}
	}

	int prow, pcol;
	Queue_Inverse();
	Queue_Search(Row - 1,Col - 1, &prow, &pcol);
	i = Row - 1, j = Col - 1;
	while(1)
	{
		if (prow == i) // r l
		{
			if (pcol > j) // l
			{
				Line ltemp = { baseX + Length * (pcol + 0.5), baseY + Length * (prow + 0.5), baseX + Length * (pcol - 0.5), baseY + Length * (prow + 0.5) };
				Path.push_back(ltemp);
			}
			else // r
			{
				Line ltemp = { baseX + Length * (pcol + 0.5), baseY + Length * (prow + 0.5), baseX + Length * (pcol + 1.5), baseY + Length * (prow + 0.5) };
				Path.push_back(ltemp);
			}
		}
		else if (pcol == j) // d u
		{
			if (pcol > i) // u
			{
				Line ltemp = { baseX + Length * (pcol + 0.5), baseY + Length * (prow + 0.5), baseX + Length * (pcol + 0.5), baseY + Length * (prow - 0.5) };
				Path.push_back(ltemp);
			}
			else // d
			{
				Line ltemp = { baseX + Length * (pcol + 0.5), baseY + Length * (prow + 0.5), baseX + Length * (pcol + 0.5), baseY + Length * (prow + 1.5) };
				Path.push_back(ltemp);
			}
		}
		i = prow, j = pcol;
		Queue_Search(prow, pcol, &prow, &pcol);
		if (prow == -1)
			break;
	}

	//�������ġ
	return 0;
}


void Push(int row, int col)
{
	Node* temp = (Node*)malloc(sizeof(Node));
	temp->row = row;
	temp->col = col;
	temp->next = NULL;
	
	if (Mtop == NULL)
	{
		Mtop = temp;
	}
	else
	{
		temp->next = Mtop;
		Mtop = temp;
	}
}

void Pop(int* row, int* col)
{
	if (Mtop == NULL)
	{
		*row = -1;
		return;
	}

	Node* temp = Mtop;
	*row = temp->row;
	*col = temp->col;
	
	Mtop = temp->next;
	free(temp);
}

void Enqueue(int row, int col, int prow, int pcol)
{
	QNode* temp = (QNode*)malloc(sizeof(QNode));
	temp->row = row;
	temp->col = col;
	temp->next = NULL;
	temp->prow = prow;
	temp->pcol = pcol;

	if (Mfront == NULL)
	{
		Mfront = temp;
		Mrear = temp;
	}
	else
	{
		Mrear->next = temp;
		Mrear = temp;
	}
	if (Mprev != NULL && Mprev->next == NULL)
		Mprev->next = temp;
}

void Dequeue(int* row, int* col) // �ӽ� ���� (������ ���������� ����)
{
	if (Mfront == NULL)
	{
		*row = -1;
		return;
	}

	QNode* temp = Mfront;
	*row = temp->row;
	*col = temp->col;

	Mfront = temp->next;
	Mprev = temp;
}

void Queue_Inverse()
{
	QNode* temp, * ptr, *trail = NULL;
	for (ptr = Mptr; ptr != NULL;)
	{
		temp = ptr->next;
		ptr->next = trail;
		trail = ptr;
		ptr = temp;
	}
	Mptr = trail;
}

void Queue_Search(int row, int col, int* prow, int* pcol)
{
	*prow = -1; *pcol = -1;
	int i, j;
	for (;Mptr != NULL;)
	{
		QNode* temp = Mptr;
		i = temp->row;
		j = temp->col;

		if (i == row && j == col)
		{
			*prow = temp->prow;
			*pcol = temp->pcol;
			return;
		}

		Mptr = Mptr->next;
		free(temp);
	}
}


void ClearStack()
{
	for (; Mtop != NULL;)
	{
		Node* temp = Mtop;
		Mtop = Mtop->next;
		free(temp);
	}
	Mtop = NULL;
}

void ClearQueue()
{
	for (; Mptr != NULL;)
	{
		QNode* temp = Mptr;
		Mptr = Mptr->next;
		free(temp);
	}
	Mrear = NULL;
	Mfront = NULL;
	Mptr = NULL;
	Mprev = NULL;
}