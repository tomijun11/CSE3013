// 사용할 라이브러리 및 헤더파일 include
#include "str.h"
#include <iostream>
using namespace std; // std::를 생략함

int main(void)
{
	Str a("I'm a girl"); // Str(char* neyong) 생성자 실행, 입력된 문자열로  객체a의 문자열을 초기화함
	cout << a.contents(); // 객체a의 문자열 출력
	a = "I'm a boy\n"; // a에 문자열의 내용을 대입함
	cout << a.contents(); // 객체a의 문자열 출력
	cout << a.compare("I'm a a") << endl; // 객체a의 문자열과 입력된 문자열을 strcmp로 비교한 결과값을 출력함
	
	Str S1(5); // Str(int leng) 생성자 실행, 입력된 길이의 문자열을 저장할 수 있는 크기만큼의 메모리를 할당함. (공백문자(' ')로 초기화됨)
	cout << S1.contents()<<endl; // 객체 S1의 문자열 출력
	cout << S1.length() << endl; // 객체 S1의 문자열의 길이를 출력 (null문자 미포함)
	S1 = a; // 객체 S1에 객체a의 문자열의 내용을 복사함
	cout << S1.contents()<<endl; // 객체 S1의 문자열 출력
	cout << S1.length() << endl; // 객체 S1의 문자열의 길이를 출력 (null문자 미포함)
	cout << a.compare(S1) << endl; // 객체S1의 문자열과 객체a의 문자열을 strcmp로 비교한 결과값을 출력함
	
	return 0;
	// main 함수의 종료와 함께 소멸자 호출됨(S1, a)
}
