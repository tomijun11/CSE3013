#include "str.h"
#include <cstring>
#include <iostream>
using namespace std;

Str::Str(int leng) // len에\0을포함하지 않음
{
	// leng이 유효한값인지 체크
	if (leng >= 0) // leng이 0이상이면 (유효한값)
	{
		len = leng; // len을 leng으로 초기화
		str = new char[len+1]; // str에 메모리 할당(len : 스트링길이,+1: null문자)
		for (int i = 0; i < len; i++) // 할당된 메모리를 초기화
			str[i] = ' '; // ' '으로 초기화함
		str[len] = '\0'; // 문자열이므로 마지막에 null추가
	}
	else // leng이 음수이면 (유효하지 않은값)
	{	
		cout << "invaild string size" << endl; // 에러메세지 출력
		len = 0; // len을 0으로 초기화
	}
}

Str::Str(char* neyong) // len에\0을포함하지 않음
{
	// neyong이 유효한값인지 체크
	if (neyong == NULL) // neyong이 null 포인터일 경우 (유효하지 않은값)
	{
		cout << "invaild string" << endl; // 에러메세지 출력
		len = 0; // len을 0으로 초기화
	}
	else // neyong이 null포인터가 아닐경우 (유효한값)
	{
		len = strlen(neyong); // len을 neyong 스트링의 길이로 초기화
		str = new char[len + 1]; // str에 메모리 할당(len : 스트링길이,+1: null문자)
		strcpy(str, neyong); // neyong의 내용을 str에 복사
	}
}

Str::~Str() 
{
	delete []str; // str포인터 메모리 할당 해제 
}

int Str::length(void)
{
	return len; // 스트링의 길이 (len값) 리턴
}

char* Str::contents(void)
{
	return str; // str 포인터값 리턴 (문자열의 주소)
}

int Str::compare(class Str& a)
{
	return strcmp(str, a.contents()); // str과 객체a의 str을 strcmp로 비교한 결과값을 리턴
}

int Str::compare(char* a)
{
	return strcmp(str, a); // str과 스트링 a를 strcmp로 비교한 결과값을 리턴
}

void Str::operator=(char* a)
{
	/*
	str에 할당된 메모리를 해제한뒤
	스트링a의 길이만큼 메모리를 할당 하고
	len에 스트링a의 길이를, str에 스트링a의 내용을 복사한다. 
	*/
	delete []str; // str에 할당된 메모리 해제
	if (a == NULL) // a가 null포인터인 경우 (유효하지 않은값)
	{
		len = 0; // len에 0을 저장
		str = new char[1]; // 메모리 할당 (null문자용)
		str[0] = '\0'; // null문자 저장
	}
	else // a가 null포인터가 아닐경우 (유효한값)
	{
		len = strlen(a); // 스트링a의 길이를 len에 저장(null문자 미포함)
		str = new char[len + 1]; // str에 메모리 할당
		strcpy(str, a); // 문자열 a의 내용을 str에 복사
	}
}

void Str::operator=(class Str& a)
{
	/*
	str에 할당된 메모리를 해제한뒤
	객체a의 스트링의 길이만큼 메모리를 할당 하고
	len에 객체a의 스트링의 길이를, str에 스트링 내용을 복사한다. 
	*/
	char* ptr = a.contents(); // 객체a의 스트링 주소를 ptr에 저장함
	delete[]str; // str에 할당된 메모리 해제
	if (ptr == NULL) // ptr이 Null포인터인 경우 (유효하지 않은값)
	{
		len = 0; // len에 0을 저장
		str = new char[1]; // 메모리 할당 (null문자용)
		str[0] = '\0'; // null문자 저장
	}
	else // ptr이 null포인터가 아닐경우 (유효한값)
	{
		len = a.length(); // 객체a의 스트링의 길이를 len에 저장
		str = new char[len + 1]; // str에 메모리 할당
		strcpy(str, ptr); // ptr의 내용을 str에 복사
	}
}



