#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define RAND() (rand()%2) // T/F Random
typedef struct _room{ // 1 : �� ����, 0 : �� ����
	int set; // ���� 
	int r; // ���� ��
	int d; // �Ʒ� ��
}Room;

Room** Maze = NULL;
int main(void)
{
	srand(time(NULL));
	int M, N, i, j, k; // M : row, N : col
	scanf("%d", &N);
	scanf("%d", &M);
	
	FILE* fp = fopen("maze0.maz", "w");
	
	Maze = (Room**)malloc(sizeof(Room*) * M);
	for (i = 0; i < M; i++)
		Maze[i] = (Room*)malloc(sizeof(Room) * N);
	

	// �ʱ�ȭ (��� ���� �����ִ� �̷�)
	for (i = 0; i < M; i++)
		for (j = 0; j < N; j++)
		{
			Maze[i][j].set = i * M + j + 1;
			Maze[i][j].r = 1;
			Maze[i][j].d = 1;
		}

	// 2->4 �ݺ� ����
	for (i = 0; i < M-1; i++)
	{
		// 2.
		for (j = 1; j < N; j++)
		{
			if (Maze[i][j-1].set != Maze[i][j].set && RAND())
			{
				Maze[i][j-1].r = 0;
				Maze[i][j].set = Maze[i][j-1].set;
			}
		}

		// 3.
		for (j = 0; j < N;)
		{
			for (k = j; k < N; k++)
			{
				if (Maze[i][j].set != Maze[i][k].set)
					break;
			}
			k--;
			int target = rand() % (k - j + 1) + j;
			Maze[i][target].d = 0;
			Maze[i + 1][target].set = Maze[i][j].set;
			j = k + 1;
		}
	
		// 4. -> �ʱ�ȭ���� �̹� ó����
	}
	// �������� ó��
	for (j = 0; j < N - 1; j++)
	{
		if (Maze[i][j].set != Maze[i][j + 1].set)
		{
			Maze[i][j].r = 0;
			if (Maze[i - 1][j].d == 1 && Maze[i - 1][j + 1].d == 1)
				Maze[i][j + 1].set = Maze[i][j].set;
			else if (Maze[i - 1][j].d == 0 && Maze[i - 1][j + 1].d == 1)
				Maze[i][j + 1].set = Maze[i][j].set;
			else if (Maze[i - 1][j].d == 1 && Maze[i - 1][j + 1].d == 0)
				Maze[i][j].set = Maze[i][j + 1].set;
			else if (Maze[i - 1][j].d == 0 && Maze[i - 1][j + 1].d == 0)
				Maze[i][j].set = Maze[i][j + 1].set;
		}
	}
	
	// ���Ϸ� ���

	// �� ����
	for (j = 0; j < 2*N+1; j++)
		if (j % 2 == 0)
			fprintf(fp, "+");
		else
			fprintf(fp, "-");
	fprintf(fp, "\n");

	for (i = 0; i < M; i++)
	{
		// �� ���
		fprintf(fp, "|");
		for (j = 0; j < N; j++)
		{
			fprintf(fp, " "); // "x"
			if (Maze[i][j].r == 1)
				fprintf(fp, "|");
			else
				fprintf(fp, " "); // "  "
		}
		fprintf(fp, "\n");

		// �� ���
		fprintf(fp, "+");
		for (j = 0; j < N; j++)
		{
			if (Maze[i][j].d == 1)
				fprintf(fp, "-");	
			else
				fprintf(fp, " "); // "  "
			fprintf(fp, "+");
		}
		fprintf(fp, "\n");
	}

	fclose(fp);
	return 0;
}