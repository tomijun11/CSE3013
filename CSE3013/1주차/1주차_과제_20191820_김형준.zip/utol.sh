echo 'Working directory'
read dirname

if [ -n "$dirname" ] 
then
	if [[ !(-d "$dirname") || !(-r "$dirname") ]];
        then
                echo "invaild directory name"
                exit
        fi
	cd $dirname
	if [ -z "$(ls)" ]; then
		exit	
	fi
fi

for dir in *
do
	if [ -f "$dir" ]; then
		newname=$(echo $dir | tr "[A-Z] [a-z]" "[a-z] [A-Z")
		mv $dir $newname
	fi
done
